-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2021 at 11:40 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dektopcustomizer`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_custreg`
--

CREATE TABLE `tbl_custreg` (
  `cust_id` int(2) NOT NULL,
  `cust_name` varchar(30) NOT NULL,
  `cust_email` varchar(50) NOT NULL,
  `cust_address` varchar(500) NOT NULL,
  `cust_phone` varchar(10) NOT NULL,
  `cust_status` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_custreg`
--

INSERT INTO `tbl_custreg` (`cust_id`, `cust_name`, `cust_email`, `cust_address`, `cust_phone`, `cust_status`) VALUES
(1, 'dona', 'dona@gmail.com', 'Kottayam \r\nKerala \r\nIndia', '9447956626', 'A'),
(2, 'Ammu', 'ammu@gmail.com', 'Kerala', '9120543874', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `login_id` int(2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL,
  `usertype` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`login_id`, `username`, `password`, `usertype`) VALUES
(1, 'dona@gmail.com', 'Dona@123', 'C'),
(2, 'ammu@gmail.com', 'Ammu@123', 'C'),
(3, 'admin@gmail.com', 'Admin@123', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_custreg`
--
ALTER TABLE `tbl_custreg`
  ADD PRIMARY KEY (`cust_id`),
  ADD UNIQUE KEY `cust_email` (`cust_email`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`login_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_custreg`
--
ALTER TABLE `tbl_custreg`
  MODIFY `cust_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `login_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
