<?php
require_once("../classes/FormAssist.class.php");
require_once("../classes/FormValidator.class.php");
require_once("../classes/DataAccess.class.php");

$elements = array("licno"=>"","name"=>"","address"=>"","phone"=>"","email"=>"");
$rules=array(  "licno"=>array("required"=>""),"name"=>array("required"=>true,"maxlength"=>20,"alphaonly"=>true),
               "address"=>array("required"=>true,"minlength"=>3,"maxlength"=>500),
			  "phone"=>array("required"=>true,"minlength"=>10,"maxlength"=>10),
			  "email"=>array("required"=>true,"email"=>true,"unique"=>array("field"=>"email","table"=>"tbl_staffreg")));
$labels=array();
$form = new FormAssist($elements,$_POST);
$validator = new FormValidator($rules,$labels);
$dao = new DataAccess();
if(isset($_POST["Register"]))
{
  if($validator->validate($_POST))
  {
     //var_dump($_POST);
    $data = array("staff_licno"=>$_POST["licno"],"staff_name"=>$_POST["name"],"staff_email"=>$_POST["email"],"staff_address"=>$_POST["address"],"staff_phone"=>$_POST["phone"],"staff_status"=>"p");

        if($dao->insert($data,"tbl_staffreg"))
        {
           
            $d=array("username"=>$_POST["email"],"password"=>"pending","usertype"=>"S");
            if($dao->insert($d,"tbl_login"))
            {
                $msg="Success";
            }
            else
            {  
                var_dump($dao->lastQuery());
                $msg="Failed, please try again";
            }

        }
        else
        {  
            var_dump($dao->lastQuery());
            $msg="Failed ,please try again";
        }
  }
  else
  {
        $msg="Failed ,please try again";
//var_dump($dao->getQuery());

  }
}
else
{
    $error=true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
<link rel="stylesheet"href="css/style.css">
<title>Bootstrap Sign up Form with Icons</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<style>
body {
	color: #fff;
	background-image: url("../img/bg-01.jpg");
	/*background: #19aa8d;*/
	background-size: cover;
	background-position: center;
	height: 100%
	background-repeat: no-repeat;
	font-family: 'Roboto', sans-serif;
}
.form-control {
	font-size: 15px;
}
.form-control, .form-control:focus, .input-group-text {
	border-color: #e1e1e1;
}
.form-control, .btn {        
	border-radius: 3px;
}
.signup-form {
	width: 400px;
	margin: 0 auto;
	padding: 30px 0;		
}
.signup-form form {
	color: #999;
	border-radius: 3px;
	margin-bottom: 15px;
	background: #fff;
	box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	padding: 30px;
}
.signup-form h2 {
	color: #333;
	font-weight: bold;
	margin-top: 0;
}
.signup-form hr {
	margin: 0 -30px 20px;
}
.signup-form .form-group {
	margin-bottom: 20px;
}
.signup-form label {
	font-weight: normal;
	font-size: 15px;
}
.signup-form .form-control {
	min-height: 38px;
	box-shadow: none !important;
}	
.signup-form .input-group-addon {
	max-width: 42px;
	text-align: center;
}	
.signup-form .btn, .signup-form .btn:active {        
	font-size: 16px;
	font-weight: bold;
	background: #19aa8d !important;
	border: none;
	min-width: 140px;
}
.signup-form .btn:hover, .signup-form .btn:focus {
	background: #179b81 !important;
}
.signup-form a {
	color: #fff;	
	text-decoration: underline;
}
.signup-form a:hover {
	text-decoration: none;
}
.signup-form form a {
	color: #19aa8d;
	text-decoration: none;
}	
.signup-form form a:hover {
	text-decoration: underline;
}
.signup-form .fa {
	font-size: 21px;
}
.signup-form .fa-paper-plane {
	font-size: 18px;
}
.signup-form .fa-check {
	color: #fff;
	left: 17px;
	top: 18px;
	font-size: 7px;
	position: absolute;
}
.a
{
	  color: white;
       text-decoration: none;
}
</style>
</head>
<body>
	<header class="header">
        <h2 class="u-name">PC <b>ZONE</b>
        </h2>
        <i aria-hidden="true">
          <a href="../index.html" class="a">  Back</a></i>
    </header>
<div class="signup-form">
    <form  method="post" enctype="multipart/form-data">
		<h2>Sign Up</h2>
		<p>Please fill in this form to create an account!</p>
		<hr>
		<div class="form-group">
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text">
						<i class="fa fa-id-card-o"></i>
					</span>                    
				</div>
				<?php echo $form->textBox("licno",array("id"=>"licno","placeholder"=>"Licence Number","class"=>"form-control")); ?> 
					<?php echo $validator->error("licno"); ?> 
			</div>
        </div>
        <div class="form-group">
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text">
						<span class="fa fa-user"></span>
					</span>                    
				</div>
				<?php echo $form->textBox("name",array("id"=>"name","placeholder"=>"Name","class"=>"form-control")); ?> 
						 <font color=red size=2><?php echo $validator->error("name"); ?>
			</div>
        </div>
        <div class="form-group">
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text">
						<i class="fa fa-paper-plane"></i>
					</span>                    
				</div>
				<?php echo $form->textBox("email",array("id"=>"email","placeholder"=>"Email","class"=>"form-control")); ?> 
				<?php echo $validator->error("email"); ?>
						 
			</div>
        </div>
        <div class="form-group">
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text">
						<i class="fa fa-phone"></i>
					</span>                    
				</div>
				<?php echo $form->textBox("phone",array("id"=>"phone","placeholder"=>"Contact Number","class"=>"form-control")); ?> 
					<?php echo $validator->error("phone"); ?> 
			</div>
        </div>
        <div class="form-group">
			<div class="input-group">
				<div class="input-group-prepend">
					<span class="input-group-text">
						<span class="fa fa-address-book"></span>
					</span>                    
				</div>
				<?php echo $form->textArea("address",array("id"=>"address","placeholder"=>"Address","class"=>"form-control")); ?>
						<?php echo $validator->error("address"); ?>
			</div>
        </div>

		       
		<div class="form-group">
			<input type="submit" class="btn btn-primary btn-lg" name="Register" value="Register">
            
        </div>
        <h1><?php echo isset($msg)?$msg:""; ?></h1>
    </form>
	<div class="text-center">Already have an account? <a href="../login.php">Login here</a></div>
</div>
</body>
</html>