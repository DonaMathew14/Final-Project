<?php
session_start();
$mgr_id=$_SESSION["mgr_id"];
$nm=$_SESSION["mgr_name"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Customer Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
	<style>
		.a
      {
            color: white;
       text-decoration: none;
      }
	</style>
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">PC <b>ZONE</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true">
          <a href="../logout.php" class="a">  Logout</a></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="img/user.jpg">
				<h4>Hi, <?php echo strtoupper($nm);  ?></h4>
			</div>
			<ul>
				<li>
					<a href="viewmgrprofile.php">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span>Profile</span>
					</a>
				</li>
				<li>
					<a href="staffrequestpending.php">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span>Staff Request</span>
					</a>
				</li>
				<li>
					<a href="addproduct.php">
						<i class="fa fa-check-circle-o" aria-hidden="true"></i>
						<span>Add Product</span>
					</a>
				</li>
				<li>
					<a href="viewproduct.php">
						<i class="fa fa-check-circle-o" aria-hidden="true"></i>
						<span>View Product</span>
					</a>
				</li>
				<li>
					<a href="viewstaff.php">
						<i class="fa fa-check-circle-o" aria-hidden="true"></i>
						<span>View Staff</span>
					</a>
				</li>
				<li>
					<a href="">
						<i class="fa fa-check-circle-o" aria-hidden="true"></i>
						<span>Feedback</span>
					</a>
				</li>
			</ul>
		</nav>
		<section class="section-1">
			
		</section>
	</div>

</body>
</html>