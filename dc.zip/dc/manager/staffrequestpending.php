<?php
require_once("../classes/FormAssist.class.php");
require_once("../classes/DataAccess.class.php");
require_once("../classes/FormValidator.class.php");

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
$dao=new DataAccess();

if(isset($_POST["id"]))
{
  $id=$_POST["id"];
    $otp=rand(100000,999999);   

  $data2= $dao->getData("staff_email","tbl_staffreg","staff_id='$id'");
  $email = $data2[0]["staff_email"];

  $data1["password"] = $otp;

  if(isset($_POST["accept"]))
  {
    $data["staff_status"]="a";

    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Mailer = "smtp";
    $mail->SMTPDebug  = 1;  
    $mail->SMTPAuth   = TRUE;
    $mail->SMTPSecure = "tls";
    $mail->Port       = 587;
    $mail->Host       = "smtp.gmail.com";
    $mail->Username   = "projectfinal142319@gmail.com";
    $mail->Password   = "Project@2021";

    $mail->IsHTML(true);
    $mail->AddAddress($email, "smk");
    $mail->SetFrom("projectfinal142319@gmail.com", "your name");
    $mail->AddReplyTo("projectfinal142319@gmail.com", "Your name");
//$mail->AddCC("cc-recipient-email@domain", "cc-recipient-name");
    $mail->Subject = "You have been accepted to the system.";
    $content = "<b>Use the OTP and mail id to login.</b>".$otp;

    $mail->MsgHTML($content); 
    if(!$mail->Send()) 
    {
      echo "Error while sending Email.";
      //var_dump($mail);
    } 
    else 
    {
      echo "Email sent successfully";
    }

  }
  else if(isset($_POST["reject"]))
  {
    $data["staff_status"]="r";
    
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Mailer = "smtp";
    $mail->SMTPDebug  = 1;  
    $mail->SMTPAuth   = TRUE;
    $mail->SMTPSecure = "tls";
    $mail->Port       = 587;
    $mail->Host       = "smtp.gmail.com";
    $mail->Username   = "projectfinal142319@gmail.com";
    $mail->Password   = "Project@2021";

    $mail->IsHTML(true);
    $mail->AddAddress($email, "smk");
    $mail->SetFrom("projectfinal142319@gmail.com", "your name");
    $mail->AddReplyTo("projectfinal142319@gmail.com", "Your name");
//$mail->AddCC("cc-recipient-email@domain", "cc-recipient-name");
    $mail->Subject = "Request Rejected.";
    $content = "<b>Your request to access the system hass been rejected!</b>";

    $mail->MsgHTML($content); 
    if(!$mail->Send()) 
    {
      echo "Error while sending Email.";
      //var_dump($mail);
    } 
    else 
    {
      echo "Email sent successfully";
    }
  }
  else
  {
    //
  }
  if($dao->update($data,"tbl_staffreg","staff_id=$id"))
  {
    if($dao->update($data1,"tbl_login","username='$email'"))
    {
      var_dump($dao->getErrors());
    }
    else
    {
      var_dump($dao->getErrors());
    }

  }

}
$fields=array("staff_id"=>"","staff_licno"=>"","staff_name"=>"","staff_address"=>"","staff_phone"=>"","staff_email"=>"");
$c="p";
$labels=array();
$form=new FormAssist($fields,$_POST);


        if($data= $dao->getData("*","tbl_staffreg","staff_status='$c'"))
        {//var_dump($rqst);
          ?>
          <table>
            <tr>
              <th>ID</th>
              <th>License Number</th>
              <th>Name</th>
              <th>Email</th>
              <th>Address</th>
              <th>Contact Number</th>
              
            </tr>
            <?php
            foreach($data as $rqst)
            {
              $un=$rqst["staff_email"];
              ?>
              <form method="POST">
              <tr>
                
                <input type="hidden" name="id" value="<?php echo $rqst["oreg_id"]; ?>">
                <td><?php echo $rqst["staff_id"]; ?></td></input>
                <td><?php echo $rqst["staff_licno"]; ?></td>
                <td><?php echo $rqst["staff_name"]; ?></td>
                <td><?php echo $rqst["staff_email"]; ?></td>
                <td><?php echo $rqst["staff_phone"]; ?></td>
                
                <td><input type="submit" name="accept" value="accept" />></td>
                <td><input type="submit" name="reject" value="reject" />></td>
              </tr>
            </form>

              <?php
            }

            ?>

          </table>


        <?php
      }
      else
      {
        echo "<h3>Error ".var_dump($dao->getErrors())."</h3>";
      }
      echo isset($msg)?$msg:""; 
     
      


    ?>
   