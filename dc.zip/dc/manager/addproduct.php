<?php
session_start();
$mgr_id=$_SESSION["mgr_id"];
$nm=$_SESSION["mgr_name"];
?>
<!DOCTYPE html>
<html>
<head>
  <title>Customer Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">



  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="How to build homes for the future?, Building Company, General Contracting, We're building
the future together, Let's work together, About Us, Built on a Strong Foundation, Ecological Architecture, Interior Architectural Designs, Contact us, Follow us">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Page 1</title>
    <link rel="stylesheet" href="css/nicepage.css" media="screen">
<link rel="stylesheet" href="css/Page-1.css" media="screen">
    <meta name="generator" content="Nicepage 3.13.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Oswald:200,300,400,500,600,700|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">




  <style>
    .a
      {
            color: white;
       text-decoration: none;
      }
  </style>
</head>
<body class="u-body">
  <input type="checkbox" id="checkbox">
  <header class="header">
    <h2 class="u-name">PC <b>ZONE</b>
      <label for="checkbox">
        <i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
      </label>
    </h2>
    <i class="fa fa-user" aria-hidden="true">
          <a href="../logout.php" class="a">  Logout</a></i>
  </header>
  <div class="body">
    <nav class="side-bar">
      <div class="user-p">
        <img src="img/user.jpg">
        <h4>Hi, <?php echo strtoupper($nm);  ?></h4>
      </div>
      <ul>
        <li>
          <a href="viewmgrprofile.php">
            <i class="fa fa-user" aria-hidden="true"></i>
            <span>Profile</span>
          </a>
        </li>
        <li>
          <a href="staffrequestpending.php">
            <i class="fa fa-user" aria-hidden="true"></i>
            <span>Staff Request</span>
          </a>
        </li>
        <li>
          <a href="addproduct.php">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>Add Product</span>
          </a>
        </li>
        <li>
          <a href="viewproduct.php">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>View Product</span>
          </a>
        </li>
        <li>
          <a href="viewstaff.php">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>View Staff</span>
          </a>
        </li>
        <li>
          <a href="">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>Feedback</span>
          </a>
        </li>
      </ul>
    </nav>
    <section class="section-1">




       <section class="u-align-center u-clearfix u-custom-color-1 u-section-1" src="" id="carousel_72a3">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h1 class="u-text u-text-1">ADD PRODUCTS</h1>
        <div class="u-expanded-width u-repeater u-repeater-1">
          <div class="u-black u-container-style u-list-item u-repeater-item u-list-item-1">
            <div class="u-container-layout u-similar-container u-container-layout-1">
              <div alt="" class="u-image u-image-circle u-image-1" data-image-width="500" data-image-height="500"></div>
              <h4 class="u-align-center u-text u-text-2">PROCESSOR</h4>
              <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-3 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-1">ADD</a>
            </div>
          </div>
          <div class="u-align-center u-black u-container-style u-list-item u-repeater-item u-video-cover">
            <div class="u-container-layout u-similar-container u-container-layout-2">
              <div alt="" class="u-image u-image-circle u-image-2" data-image-width="500" data-image-height="500"></div>
              <h4 class="u-align-center u-text u-text-3">KEYBOARD</h4>
              <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-3 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-2">ADD</a>
            </div>
          </div>
          <div class="u-align-center u-black u-container-style u-list-item u-repeater-item u-video-cover">
            <div class="u-container-layout u-similar-container u-container-layout-3">
              <div alt="" class="u-image u-image-circle u-image-3" data-image-width="500" data-image-height="500"></div>
              <h4 class="u-align-center u-text u-text-4">MOUSE</h4>
              <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-3 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-3">ADD</a>
            </div>
          </div>
          <div class="u-align-center u-black u-container-style u-list-item u-repeater-item u-video-cover">
            <div class="u-container-layout u-similar-container u-container-layout-4">
              <div alt="" class="u-image u-image-circle u-image-4" data-image-width="243" data-image-height="207"></div>
              <h4 class="u-align-center u-text u-text-5">MONITOR</h4>
              <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-3 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-4">ADD</a>
            </div>
          </div>
        </div>
        <div class="u-expanded-width u-list u-list-1">
          <div class="u-repeater u-repeater-2">
            <div class="u-black u-container-style u-list-item u-repeater-item u-list-item-5">
              <div class="u-container-layout u-similar-container u-container-layout-5">
                <div alt="" class="u-image u-image-circle u-image-5" data-image-width="335" data-image-height="150"></div>
                <h4 class="u-align-center u-text u-text-6">RAM</h4>
                <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-2 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-5">ADD</a>
              </div>
            </div>
            <div class="u-align-center u-black u-container-style u-list-item u-repeater-item u-video-cover">
              <div class="u-container-layout u-similar-container u-container-layout-6">
                <div alt="" class="u-image u-image-circle u-image-6" data-image-width="500" data-image-height="500"></div>
                <h4 class="u-align-center u-text u-text-7">CABINET</h4>
                <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-2 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-6">ADD</a>
              </div>
            </div>
            <div class="u-align-center u-black u-container-style u-list-item u-repeater-item u-video-cover">
              <div class="u-container-layout u-similar-container u-container-layout-7">
                <div alt="" class="u-image u-image-circle u-image-7" data-image-width="1500" data-image-height="1138"></div>
                <h4 class="u-align-center u-text u-text-8">HARD DISK</h4>
                <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-2 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-7">ADD</a>
              </div>
            </div>
            <div class="u-align-center u-black u-container-style u-list-item u-repeater-item u-video-cover">
              <div class="u-container-layout u-similar-container u-container-layout-8">
                <div alt="" class="u-image u-image-circle u-image-8" data-image-width="768" data-image-height="384"></div>
                <h4 class="u-align-center u-text u-text-9">MOTHERBOARD</h4>
                <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-2 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-8">ADD</a>
              </div>
            </div>
            <div class="u-align-center u-black u-container-style u-list-item u-repeater-item u-video-cover">
              <div class="u-container-layout u-similar-container u-container-layout-9">
                <div alt="" class="u-image u-image-circle u-image-9" data-image-width="321" data-image-height="253"></div>
                <h4 class="u-align-center u-text u-text-10">SOFTWARE</h4>
                <a href="https://nicepage.com/c/gallery-website-templates" class="u-active-palette-3-light-2 u-border-2 u-border-white u-btn u-btn-rectangle u-button-style u-custom-color-1 u-hover-palette-3-base u-btn-9">ADD</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
      
    </section>
  </div>

</body>
</html>