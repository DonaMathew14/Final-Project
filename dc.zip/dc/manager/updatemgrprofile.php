<?php
session_start();
$mgr_id=$_SESSION["mgr_id"];
$nm=$_SESSION["mgr_name"];
var_dump($mgr_id);


require_once("../classes/FormAssist.class.php");
require_once("../classes/DataAccess.class.php");
require_once("../classes/FormValidator.class.php");
$dao=new DataAccess();

$rules= array("mgr_name"=>array("required"=>"","minlength"=>3,"maxlength"=>20,"nospecchars"=>"","alphaspaceonly"=>""),"mgr_phone"=>array("required"=>"","minlength"=>10,"maxlength"=>10),
        "mgr_email"=>array("required"=>"","email"=>""),"mgr_address"=>array("required"=>"")
        );

$labels=array();
$validator=new FormValidator($rules,$labels);
if(isset($_POST["update"]))
{
  if($validator->validate($_POST))
  {

       $data = array("mgr_name"=>$_POST["mgr_name"],"mgr_email"=>$_POST["mgr_email"],"mgr_phone"=>$_POST["mgr_phone"]);

        if($dao->update($data,"tbl_manager","mgr_id=$mgr_id"))
        {


        //header("location:index.php");
          $msg="Updated";

        }
        else
        {    
            $msg="Failed ,please try again";
        }
  }
  else
  {
  $msg="Failed ,val error";
  //var_dump($dao->getQuery());

  }
}

$res=$dao->getData("*","tbl_manager","mgr_id=$mgr_id");
$details=$res[0];
$fields=array("mgr_name"=>$details["mgr_name"],"mgr_email"=>$details["mgr_email"],"mgr_phone"=>$details["mgr_phone"],"mgr_address"=>$details["mgr_address"]);
$form=new FormAssist($fields,$_POST);
?>

<!DOCTYPE html>
<html>
<head>
      <title>AUpdate Profile</title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="css/style.css">
      <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
<title>Bootstrap Sign up Form with Icons</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>
<style>
body {
  color: #fff;
  background-image: url("../img/bg-01.jpg");
  /*background: #19aa8d;*/
  background-size: cover;
  background-position: center;
  height: 100%
  background-repeat: no-repeat;
  font-family: 'Roboto', sans-serif;
}
.form-control {
  font-size: 15px;
}
.form-control, .form-control:focus, .input-group-text {
  border-color: #e1e1e1;
}
.form-control, .btn {        
  border-radius: 3px;
}
.signup-form {
  width: 400px;
  margin: 0 auto;
  padding: 30px 0;    
}
.signup-form form {
  color: #999;
  border-radius: 3px;
  margin-bottom: 15px;
  background: #fff;
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  padding: 30px;
}
.signup-form h2 {
  color: #333;
  font-weight: bold;
  margin-top: 0;
}
.signup-form hr {
  margin: 0 -30px 20px;
}
.signup-form .form-group {
  margin-bottom: 20px;
}
.signup-form label {
  font-weight: normal;
  font-size: 15px;
}
.signup-form .form-control {
  min-height: 38px;
  box-shadow: none !important;
} 
.signup-form .input-group-addon {
  max-width: 42px;
  text-align: center;
} 
.signup-form .btn, .signup-form .btn:active {        
  font-size: 16px;
  font-weight: bold;
  background: #19aa8d !important;
  border: none;
  min-width: 140px;
}
.signup-form .btn:hover, .signup-form .btn:focus {
  background: #179b81 !important;
}
.signup-form a {
  color: #fff;  
  text-decoration: underline;
}
.signup-form a:hover {
  text-decoration: none;
}
.signup-form form a {
  color: #19aa8d;
  text-decoration: none;
} 
.signup-form form a:hover {
  text-decoration: underline;
}
.signup-form .fa {
  font-size: 21px;
}
.signup-form .fa-paper-plane {
  font-size: 18px;
}
.signup-form .fa-check {
  color: #fff;
  left: 17px;
  top: 18px;
  font-size: 7px;
  position: absolute;
}
.a
{

            color: white;
       text-decoration: none;
}
</style>
</head>
<body>
      <input type="checkbox" id="checkbox">
      <header class="header">
            <h2 class="u-name">PC <b>ZONE</b>
                  <label for="checkbox">
                        <i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
                  </label>
            </h2>
            <i class="fa fa-user" aria-hidden="true">
            <a href="../logout.php" class="a">Logout</a></i>
      </header>
      <div class="body">
            <nav class="side-bar">
                  <div class="user-p">
                        <img src="img/user.jpg">
                        <h4>Hi, <?php echo strtoupper($nm);  ?></h4>
                  </div>
                  <ul>
                        <li>
          <a href="viewmgrprofile.php">
            <i class="fa fa-user" aria-hidden="true"></i>
            <span>Profile</span>
          </a>
        </li>
        <li>
          <a href="addproduct.php">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>Add Product</span>
          </a>
        </li>
        <li>
          <a href="viewproduct.php">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>View Product</span>
          </a>
        </li>
        <li>
          <a href="viewstaff.php">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>View Staff</span>
          </a>
        </li>
        <li>
          <a href="">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>Feedback</span>
          </a>
        </li>
                  </ul>
            </nav>
            <section class="section-1">
              <form method="post" enctype="multipart/form-data">
    <h2>Update Profile</h2>
    
    <hr>
        <div class="form-group">
      <div class="input-group">
        <div class="input-group-prepend">
          <span class="input-group-text">
            <span class="fa fa-user"></span>
          </span>                    
        </div>
        <?php echo $form->textBox("mgr_name",array("placeholder"=>"mgr_name","class"=>"form-control")); ?>
                  <font color=red size=2><?php echo $validator->error("mgr_name"); ?>
      </div>
        </div>

        <div class="form-group">
      <div class="input-group">
        <div class="input-group-prepend">
          <span class="input-group-text">
            <i class="fa fa-paper-plane"></i>
          </span>                    
        </div>
        <?php echo $form->textBox("mgr_email",array("placeholder"=>"mgr_email","type"=>"email","class"=>"form-control")); ?>
                  <?php echo $validator->error("mgr_email"); ?>
      </div>
        </div>
        
        <div class="form-group">
      <div class="input-group">
        <div class="input-group-prepend">
          <span class="input-group-text">
            <span class="fa fa-user"></span>
          </span>                    
        </div>
        <?php echo $form->textBox("mgr_phone",array("placeholder"=>"mgr_phone","class"=>"form-control")); ?>
                  <?php echo $validator->error("mgr_phone"); ?>
      </div>
        </div>

        <div class="form-group">
      <div class="input-group">
        <div class="input-group-prepend">
          <span class="input-group-text">
            <span class="fa fa-user"></span>
          </span>                    
        </div>
        <?php echo $form->textBox("mgr_address",array("placeholder"=>"mgr_address","class"=>"form-control")); ?>
                  <?php echo $validator->error("mgr_address"); ?>
      </div>
        </div>
        
    <div class="form-group">
            <input type="submit" class="btn btn-primary btn-lg" name="update" value="Update" />
        </div>
    </form>

        </section>
   

</body>
</html>









