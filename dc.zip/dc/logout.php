<?php
	session_start();
	session_destroy();
	header("location:login.php");
	
?>
<!DOCTYPE html>
<html>
<head>
	<script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>
	<title></title>
</head>
<body>

</body>
</html>
	
	
