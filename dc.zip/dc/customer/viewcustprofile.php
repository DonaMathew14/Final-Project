<?php
session_start();
$cust_id=$_SESSION["cust_id"];
$nm=$_SESSION["cust_name"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Customer Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
	<script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>
	<style>
      * {
      box-sizing: border-box;
      }
      html, body {
      min-height: 100vh;
      padding: 0;
      margin: 0;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px; 
      color: #666;
      }
      input, textarea { 
      outline: none;
      }
      .section-1 {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      background: #e0e339;
      }
      h1 {
      margin-top: 0;
      font-weight: 500;
      }
      form {
      position: relative;
      width: 80%;
      border-radius: 30px;
      background: #fff;
      }
      .form-left-decoration,
      .form-right-decoration {
      content: "";
      position: absolute;
      width: 50px;
      height: 20px;
      border-radius: 20px;
      background: #e0e339;
      }
      .form-left-decoration {
      bottom: 60px;
      left: -30px;
      }
      .form-right-decoration {
      top: 60px;
      right: -30px;
      }
      .form-left-decoration:before,
      .form-left-decoration:after,
      .form-right-decoration:before,
      .form-right-decoration:after {
      content: "";
      position: absolute;
      width: 50px;
      height: 20px;
      border-radius: 30px;
      background: #fff;
      }
      .form-left-decoration:before {
      top: -20px;
      }
      .form-left-decoration:after {
      top: 20px;
      left: 10px;
      }
      .form-right-decoration:before {
      top: -20px;
      right: 0;
      }
      .form-right-decoration:after {
      top: 20px;
      right: 10px;
      }
      .circle {
      position: absolute;
      bottom: 80px;
      left: -55px;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: #fff;
      }
      .form-inner {
      padding: 40px;
      }
      .form-inner input,
      .form-inner textarea {
      display: block;
      width: 100%;
      padding: 15px;
      margin-bottom: 10px;
      border: none;
      border-radius: 20px;
      background: #d0dfe8;
      }
      .form-inner textarea {
      resize: none;
      }
      .btn {
      width: 100%;
      padding: 10px;
      margin-top: 20px;
      border-radius: 20px;
      border: none;
      border-bottom: 4px solid #c7bf30;
      background: #e0e339; 
      font-size: 16px;
      font-weight: 400;
      color: #fff;
      text-decoration: none;
      }
      .btn:hover {
      background: #c7bf30;
      } 
      @media (min-width: 568px) {
      form {
      width: 60%;
      }
      }
      table{
      	border-collapse: collapse;
      	width: 100%;

      }
      th,td{
      	text-align: left;
      	padding: 8px;

      }
      tr:nth-child(even)
      {
      	background-color: #f2f2f2;
      }
      th{
      	background-color: #c7bf30;
      	color: white;

      }
      .a
      {
            color: white;
       text-decoration: none;
      }
    </style>
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">PC <b>ZONE</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true">
          <a href="../logout.php" class="a">  Logout</a></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="img/user.jpg">
				<h4>WELCOME <?php echo strtoupper($nm);  ?></h4>
			</div>
			<ul>
				<li>
					<a href="">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span>Profile</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-check-circle-o" aria-hidden="true"></i>
						<span>Customise PC</span>
					</a>
				</li>
				<li>
					<a href="FEEDBACK">
						<i class="fa fa-check-circle-o" aria-hidden="true"></i>
						<span>Feedback</span>
					</a>
				</li>
				<li>
					
				</li>
			</ul>
		</nav>
		<section class="section-1">
			<?php 
			require_once("../classes/DataAccess.class.php");
			$dao = new DataAccess();
			$fields=array("cust_name","cust_email","cust_phone","cust_address");
			if($customer = $dao->getData($fields,"tbl_custreg","cust_id=$cust_id"))
			{
				//var_dump(students);
				?>
				<form method="post" class="decor" enctype="multipart/form-data">
      <div class="form-left-decoration"></div>
      <div class="form-right-decoration"></div>
      <div class="circle"></div>
      <div class="form-inner">
        <center><p style="color: black; font-family: satisfy">My Profile</p></center>
					<table class="table">
						<tr>
							
							<th>Name</th>
							<th>Email</th>
							
							<th>Phone Number</th>
							<th>Address</th>
							<th></th>
							
						</tr>
						<?php
						foreach($customer as $cust)
						{
							?>
							<tr>
								
								<td><?php echo $cust["cust_name"]; ?></td>
								<td><?php echo $cust["cust_email"]; ?></td>
								<td><?php echo $cust["cust_phone"]; ?></td>
								<td><?php echo $cust["cust_address"]; ?></td>
								 <td><a class="btn" href="updatecustprofile.php">Update</a></td>
								

								
							</tr>

							<?php
						}

						?>

					</table>
</div>
  </div>
    </form>

				<?php
			}
			else
			{
				echo "<h3>Error ".$dao->getErrors()."</h3>";
			}


		?>
			
		</section>
	</div>

</body>
</html>