<?php
session_start();
$cust_id=$_SESSION["cust_id"];
$em=$_SESSION["cust_email"];
$nm=$_SESSION["cust_name"];
//var_dump($cust_id);
require_once("../classes/FormAssist.class.php");
require_once("../classes/DataAccess.class.php");
require_once("../classes/FormValidator.class.php");
$dao=new DataAccess();
$elements = array("cust_name"=>"","cust_email"=>"","feedback_message"=>"");
$rules= array("feedback_message"=>array("required"=>""));
        $labels=array("cust_name","cust_email");
$form = new FormAssist($elements,$_POST);
$validator = new FormValidator($rules,$labels);
$form=new FormAssist($elements,$_POST);
$dao = new DataAccess();
if(isset($_POST["feedback"]))

{
    if($validator->validate($_POST))
    {
        
         $data = array("cust_name"=>$nm,"cust_email"=>$em,"feedback_message"=>$_POST["feedback_message"]);
    
    
    if($dao->insert($data,"tbl_feedback"))
        {
           
           $msg="Feedback send successfully";
        }
        else
        {  
              var_dump($dao->lastQuery());
              $msg="Failed ,please try again";
        }
  }
 
else
{
    $error=true;
}
}


$form=new FormAssist($elements,$_POST);
?>

<!DOCTYPE html>
<head>
    <title>Feedback</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/style.css">
<style>
    .a
      {
            color: white;
       text-decoration: none;
      }
</style>
<body>
<input type="checkbox" id="checkbox">
    <header class="header">
        <h2 class="u-name">PC <b>ZONE</b>
            <label for="checkbox">
                <i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
            </label>
        </h2>
        <i class="fa fa-user" aria-hidden="true">
          <a href="../logout.php" class="a">  Logout</a></i>
    </header>
    <div class="body">
        <nav class="side-bar">
            <div class="user-p">
                <img src="img/user.jpg">
                <h4>WELCOME <?php echo strtoupper($nm);  ?></h4>
            </div>
            <ul>
                <li>
                    <a href="viewcustprofile.php">
                        <i class="fa fa-user" aria-hidden="true"></i>
                        <span>Profile</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-check-circle-o" aria-hidden="true"></i>
                        <span>Customise PC</span>
                    </a>
                </li>
                <li>
                    <a href="feedback.php">
                        <i class="fa fa-check-circle-o" aria-hidden="true"></i>
                        <span>Feedback</span>
                    </a>
               
                </li>
                <li>
                    
                </li>
            </ul>
        </nav>
        <section class="section-1">

    <div class="container-contact100">

        <div class="wrap-contact100">
            <form class="contact100-form validate-form">
                <span class="contact100-form-title">
                    FEEDBACK
                </span>

                <div class="wrap-input100 validate-input" data-validate="Please enter your name">
                     <?php echo $form->textBox("cust_name",array("placeholder"=>"$nm","class"=>"input100")); ?>
                  
                    
                </div>

                <div class="wrap-input100 validate-input" data-validate = "Please enter your email: e@a.x">
                    <?php echo $form->textBox("cust_email",array("placeholder"=> "$em","type"=>"email","class"=>"input100")); ?>
                 
                    
                </div>

                

                <div class="wrap-input100 validate-input" data-validate = "Please enter your message">
                    <textarea class="input100" name="message" placeholder="Your Feedback Message"></textarea>
                    
                </div>



                <div class="container-contact100-form-btn">
                    <input type="submit" class="contact100-form-btn" name="feedback" value="submit">
                    
                </div>
               <h1 style="color: black;"> <?php echo isset($msg)?$msg:""; ?></h1>

            </form>
        </div>
    </div>


</section>

</body>
</html>
