<?php
session_start();
$username=$_SESSION["username"];
$admin_id=$_SESSION["admin_id"];
$nm=$_SESSION["admin_name"];
if(!isset($_SESSION['admin_name']))
{
header('location:admin/adminlogin.php');
}
$conn = mysqli_connect("localhost", "root", "", "dektopcustomizer") or die("Connection Error: " . mysqli_error($conn));

if (count($_POST) > 0)
{
    $result = mysqli_query($conn, "SELECT * from tbl_login WHERE username='" . $_SESSION["username"] . "'");
    $row = mysqli_fetch_array($result);
    if ($_POST["currentPassword"] == $row["password"])
    {
        mysqli_query($conn, "UPDATE tbl_login set password='" . $_POST["newPassword"] . "' WHERE username='" . $_SESSION["username"] . "'");
        $message = "Password Changed";
    }


    else
    {
        $message = "Current Password is not correct";
    }
    }

?>
<!DOCTYPE html>
<html>

<head>
    <title>Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th,
    td {
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #fff;
    }

    th {
        background-color: #ffb03b;
        color: white;
    }

    .btn {
        background: #ffb03b;
        color: #fff;
        border-radius: 30px;
        margin: 0 0 0 20px;
        padding: 5px 20px;
        font-size: 13px;
        font-weight: 500;
        letter-spacing: 1px;
        transition: 0.3s;
        white-space: nowrap;
    }

    * {
        box-sizing: border-box;
    }

    html,
    body {
        min-height: 100vh;
        padding: 0;
        margin: 0;
        font-family: Roboto, Arial, sans-serif;
        font-size: 14px;
        color: #666;
    }

    input,
    textarea {
        outline: none;
    }

    .section-1 {
        display: flex;
        justify-content: center;
        align-items: center;
        padding: 20px 20px 10px 10px;
        background: #e0e339;
    }

    h1 {
        margin-top: 0;
        font-weight: 500;
    }

    form {
        position: relative;
        width: 80%;
        border-radius: 30px;
        background: #fff;
    }

    .form-left-decoration,
    .form-right-decoration {
        content: "";
        position: absolute;
        width: 50px;
        height: 20px;
        border-radius: 20px;
        background: #e0e339;
    }

    .form-left-decoration {
        bottom: 60px;
        left: -30px;
    }

    .form-right-decoration {
        top: 60px;
        right: -30px;
    }

    .form-left-decoration:before,
    .form-left-decoration:after,
    .form-right-decoration:before,
    .form-right-decoration:after {
        content: "";
        position: absolute;
        width: 50px;
        height: 20px;
        border-radius: 30px;
        background: #fff;
    }

    .form-left-decoration:before {
        top: -20px;
    }

    .form-left-decoration:after {
        top: 20px;
        left: 10px;
    }

    .form-right-decoration:before {
        top: -20px;
        right: 0;
    }

    .form-right-decoration:after {
        top: 20px;
        right: 10px;
    }

    .circle {
        position: absolute;
        bottom: 80px;
        left: -55px;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #fff;
    }

    .form-inner {
        padding: 40px;
    }

    .form-inner input,
    .form-inner textarea {
        display: block;
        width: 100%;
        padding: 15px;
        margin-bottom: 10px;
        border: none;
        border-radius: 20px;
        background: #d0dfe8;
    }

    .form-inner textarea {
        resize: none;
    }

    .button {
        width: 100%;
        padding: 10px;
        margin-top: 20px;
        border-radius: 20px;
        border: none;
        border-bottom: 4px solid #ffb03b;
        background: #ffb03b;
        font-size: 16px;
        font-weight: 400;
        color: #fff;
    }

    .button:hover {
        background: #ffb03b;
    }

    @media (min-width: 568px) {
        form {
            width: 80%;
        }
    }
    .a
      {
            color: white;
       text-decoration: none;
      }
    </style>
</head>

<body>
    <script>
    function validatePassword() {
        var currentPassword, newPassword, confirmPassword, output = true;

        currentPassword = document.frmChange.currentPassword;
        newPassword = document.frmChange.newPassword;
        confirmPassword = document.frmChange.confirmPassword;

        if (!currentPassword.value) {
            currentPassword.focus();
            document.getElementById("currentPassword").innerHTML = "required";
            output = false;
        } else if (!newPassword.value) {
            newPassword.focus();
            document.getElementById("newPassword").innerHTML = "required";
            output = false;
        } else if (!confirmPassword.value) {
            confirmPassword.focus();
            document.getElementById("confirmPassword").innerHTML = "required";
            output = false;
        }
        if (newPassword.value != confirmPassword.value) {
            newPassword.value = "";
            confirmPassword.value = "";
            newPassword.focus();
            document.getElementById("confirmPassword").innerHTML = "not same";
            output = false;
        }
        return output;
    }
    </script>
    <input type="checkbox" id="checkbox">
    <header class="header">
        <h2 class="u-name">PC<b>ZONE</b>
            <label for="checkbox">
                <i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
            </label>
        </h2>
        <i class="fa fa-user" aria-hidden="true">
            <a href="../logout.php" class="a">Logout</a> </i>
    </header>
    <div class="body">
        <nav class="side-bar">
            <div class="user-p">
                <img src="img/user.jpg">
                <h4>Hi, <?php echo strtoupper($nm);  ?></h4>
            </div>
            <ul>
                <li>
                    <a href="viewadminprofile.php">
                        <i class="fa fa-desktop" aria-hidden="true"></i>
                        <span>Profile</span>
                    </a>
                </li>
                        
                <li>
                    <a href="addmanager.php">
                        <i class="fa fa-check-circle-o" aria-hidden="true"></i>
                        <span>Manager Request</span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-comment-o" aria-hidden="true"></i>
                        <span>Feedback</span>
                    </a>
                </li>
                <li>
                    <a href="viewcust.php">
                        <i class="fa fa-user-o" aria-hidden="true"></i>
                        <span>View Customer</span>
                    </a>
                </li>
                <li>
                    <a href="viewmanager.php">
                        <i class="fa fa-user-o" aria-hidden="true"></i>
                        <span>View Manager</span>
                    </a>
                </li>
                <li>
                    <a href="viewstaff.php">
                        <i class="fa fa-user-o" aria-hidden="true"></i>
                        <span>View Staff</span>
                    </a>
                </li>
                <li>
                    <a href="changepassword.php">
                        <i class="fa fa-key" aria-hidden="true"></i>
                        <span>change password</span>
                    </a>
                </li>
            </ul>
        </nav>
 
    <section class="section-1">
        <form action="" method="post" class="decor" enctype="multipart/form-data">

            <center><p style="color: black;font-family:satisfy">CHANGE PASSWORD</p></center>
                <div class="form-left-decoration"></div>
                <div class="form-right-decoration"></div>
                <div class="circle"></div>
                <div class="form-inner">
                    <table>
                        <tr>
                            <td><label>CURRENT PASSWORD<h5>(if you are changing password for the first time otp will be your current password)</h5></label></td>
                               <td> <input type="password" name="currentPassword" /><span
                            id="currentPassword" class="required"></span></td>
                            </td>
                        </tr>
                        <tr>
                            <td><label>NEW PASSWORD</label></td>
                               <td><input type="password" name="newPassword" class="txtField" /><span id="newPassword"
                            class="required"></span></td>
                            </td>
                        </tr>
                        <tr>
                            <td><label>CONFIRM PASSWORD</label></td>
                               <td><input type="password" name="confirmPassword" class="txtField" /><span id="confirmPassword"
                        class="required"></span></td>
                            </td>
                        </tr>
                        <tr>
                        <td colspan="2"><input type="submit" name="submit" value="Submit" class="btnSubmit"></td>
                        </tr>
                    </table>
                    <h5><font color="red"><?php if(isset($message)) { echo $message; } ?><h5>
                </div>
        </form>
    </section>
  </div>
</body>

</html>