<?php
session_start();
$ad_id=$_SESSION["admin_id"];
$nm=$_SESSION["admin_name"];
var_dump($ad_id);
require_once("classes/FormAssist.class.php");
require_once("classes/DataAccess.class.php");
require_once("classes/FormValidator.class.php");

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';
$dao=new DataAccess();

if(isset($_POST["id"]))
{
  $id=$_POST["id"];
    $otp=rand(100000,999999);  

  $data2= $dao->getData("mgr_email","tbl_manager","mgr_id='$id'");
  $email = $data2[0]["mgr_email"];

  $data1["password"] = $otp;

  if(isset($_POST["accept"]))
  {
    $data["mgr_status"]="a";

    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Mailer = "smtp";
    $mail->SMTPDebug  = 1;  
    $mail->SMTPAuth   = TRUE;
    $mail->SMTPSecure = "tls";
    $mail->Port       = 587;
    $mail->Host       = "smtp.gmail.com";
    $mail->Username   = "projectfinal142319@gmail.com";
    $mail->Password   = "Project@2021";

    $mail->IsHTML(true);
    $mail->AddAddress($email, "smk");
    $mail->SetFrom("projectfinal142319@gmail.com", "your name");
    $mail->AddReplyTo("projectfinal142319@gmail.com", "Your name");
//$mail->AddCC("cc-recipient-email@domain", "cc-recipient-name");
    $mail->Subject = "You have been accepted to the system.";
    $content = "<b>Use the OTP and mail id to login.</b>".$otp;

    $mail->MsgHTML($content);
    if(!$mail->Send())
    {
      echo "Error while sending Email.";
      //var_dump($mail);
    }
    else
    {
      echo "Email sent successfully";
    }

  }
  else if(isset($_POST["reject"]))
  {
    $data["mgr_status"]="r";
   
    $mail = new PHPMailer();
    $mail->IsSMTP();
    $mail->Mailer = "smtp";
    $mail->SMTPDebug  = 1;  
    $mail->SMTPAuth   = TRUE;
    $mail->SMTPSecure = "tls";
    $mail->Port       = 587;
    $mail->Host       = "smtp.gmail.com";
    $mail->Username   = "projectfinal142319@gmail.com";
    $mail->Password   = "Project@2021";

    $mail->IsHTML(true);
    $mail->AddAddress($email, "smk");
    $mail->SetFrom("projectfinal142319@gmail.com", "your name");
    $mail->AddReplyTo("projectfinal142319@gmail.com", "Your name");
//$mail->AddCC("cc-recipient-email@domain", "cc-recipient-name");
    $mail->Subject = "Request Rejected.";
    $content = "<b>Your request to access the system hass been rejected!</b>";

    $mail->MsgHTML($content);
    if(!$mail->Send())
    {
      echo "Error while sending Email.";
      //var_dump($mail);
    }
    else
    {
      echo "Email sent successfully";
    }
  }
  else
  {
    //
  }
  if($dao->update($data,"tbl_manager","mgr_id=$id"))
  {
    if($dao->update($data1,"tbl_login","username='$email'"))
    {
      var_dump($dao->getErrors());
    }
    else
    {
      var_dump($dao->getErrors());
    }

  }

}
$fields=array("mgr_id"=>"","mgr_name"=>"","mgr_email"=>"","mgr_address"=>"","mgr_doj"=>"","mgr_phone"=>"","mgr_license"=>"");
$c="p";
$labels=array();
$form=new FormAssist($fields,$_POST);


        if($data= $dao->getData("*","tbl_manager","mgr_status='$c'"))
        {//var_dump($rqst);
          ?>



<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/style.css">
  <script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>
  
  <style>
      * {
      box-sizing: border-box;
      }
      html, body {
      min-height: 100vh;
      padding: 0;
      margin: 0;
      font-family: Roboto, Arial, sans-serif;
      font-size: 14px; 
      color: #666;
      }
      input, textarea { 
      outline: none;
      }
      .section-1 {
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
      background: #e0e339;
      }
      h1 {
      margin-top: 0;
      font-weight: 500;
      }
      form {
      position: relative;
      width: 80%;
      border-radius: 30px;
      background: #fff;
      }
      .form-left-decoration,
      .form-right-decoration {
      content: "";
      position: absolute;
      width: 50px;
      height: 20px;
      border-radius: 20px;
      background: #e0e339;
      }
      .form-left-decoration {
      bottom: 60px;
      left: -30px;
      }
      .form-right-decoration {
      top: 60px;
      right: -30px;
      }
      .form-left-decoration:before,
      .form-left-decoration:after,
      .form-right-decoration:before,
      .form-right-decoration:after {
      content: "";
      position: absolute;
      width: 50px;
      height: 20px;
      border-radius: 30px;
      background: #fff;
      }
      .form-left-decoration:before {
      top: -20px;
      }
      .form-left-decoration:after {
      top: 20px;
      left: 10px;
      }
      .form-right-decoration:before {
      top: -20px;
      right: 0;
      }
      .form-right-decoration:after {
      top: 20px;
      right: 10px;
      }
      .circle {
      position: absolute;
      bottom: 80px;
      left: -55px;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: #fff;
      }
      .form-inner {
      padding: 40px;
      }
      .form-inner input,
      .form-inner textarea {
      display: block;
      width: 100%;
      padding: 15px;
      margin-bottom: 10px;
      border: none;
      border-radius: 20px;
      background: #d0dfe8;
      }
      .form-inner textarea {
      resize: none;
      }
      .btn {
      width: 100%;
      padding: 10px;
      margin-top: 20px;
      border-radius: 20px;
      border: none;
      border-bottom: 4px solid #c7bf30;
      background: #e0e339; 
      font-size: 16px;
      font-weight: 400;
      color: #fff;
      }
      .btn:hover {
      background: #c7bf30;
      } 
      @media (min-width: 568px) {
      form {
      width: 60%;
      }
      }
      table{
        border-collapse: collapse;
        width: 100%;

      }
      th,td{
        text-align: left;
        padding: 8px;

      }
      tr:nth-child(even)
      {
        background-color: #f2f2f2;
      }
      th{
        background-color: #c7bf30;
        color: white;

      }
      .a
      {
            color: white;
       text-decoration: none;
      }
    </style>
</head>
<body>
          <input type="checkbox" id="checkbox">
  <header class="header">
    <h2 class="u-name">PC <b>ZONE</b>
      <label for="checkbox">
        <i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
      </label>
    </h2>
    <i class="fa fa-user" aria-hidden="true">
          <a href="../logout.php" class="a">  Logout</a></i>
  </header>
  <div class="body">
    <nav class="side-bar">
      <div class="user-p">
        <img src="img/user.jpg">
        <h4>Hi, <?php echo strtoupper($nm);  ?></h4>
      </div>
      <ul>
        <li>
          <a href="viewadminprofile.php">
            <i class="fa fa-user" aria-hidden="true"></i>
            <span>profile</span>
          </a>
        </li>
                        
        <li>
          <a href="addmanager.php">
            <i class="fa fa-check-circle-o" aria-hidden="true"></i>
            <span>Manager Request</span>
          </a>
        </li>
        
        <li>
          <a href="#">
            <i class="fa fa-comment-o" aria-hidden="true"></i>
            <span>Feedback</span>
          </a>
        </li>
        <li>
          <a href="viewcust.php">
            <i class="fa fa-user-o" aria-hidden="true"></i>
            <span>View Customer</span>
          </a>
        </li>
        <li>
          <a href="viewmanager.php">
            <i class="fa fa-user-o" aria-hidden="true"></i>
            <span>View Manager</span>
          </a>
        </li>
        <li>
          <a href="viewstaff.php">
            <i class="fa fa-user-o" aria-hidden="true"></i>
            <span>View Staff</span>
          </a>
        </li>
        <li>
          <a href="changepassword.php.php">
            <i class="fa fa-key" aria-hidden="true"></i>
            <span>Change Password</span>
          </a>
        </li>
      </ul>
    </nav>
    <section class="section-1">
      <form method="post" class="decor">
         
          <table>
            <tr>
              
              <th>Name</th>
              <th>Email</th>
              <th>Contact Number</th>
              <th>License Number</th>
              <th>Accept</th>
              <th>or</th>
              <th>Reject</th>
              
            </tr>
            <?php
            foreach($data as $rqst)
            {
        
              ?>
                        <tr>
               
                <input type="hidden" name="id" value="<?php echo $rqst["mgr_id"]; ?>">
                
                <td><?php echo $rqst["mgr_name"]; ?></td>
                <td><?php echo $rqst["mgr_email"]; ?></td>
                <td><?php echo $rqst["mgr_phone"]; ?></td>
                <td><?php echo $rqst["mgr_licno"]; ?></td>
                <td><input type="submit" class="btn" name="accept" value="accept" /></td>
                <td></td>
                <td><input type="submit" class="btn" name="reject" value="reject" /></td>
              </tr>
           

              <?php
            }

            ?>

          </table>
           </form>

</div>
  </div>
    </form>
    
        <?php
      }
      else
      {
        echo "<h3>Error ".var_dump($dao->getErrors())."</h3>";
       
      }
     
     
     
    ?>
    </section>
  </div>

</body>
</html>