<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="css/style.css">
<script type = "text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>
<style>
table,td,th
{

}
table
{
border-collapse: collapse;
margin: 0 auto;
width:80%;
}
td,th
{
text-align: center;
border-radius: 10px 10px 10px 10px;
height:40px;
}
tr:nth-child(even)
{
background-color:#c3e4d4;
}
tr:nth-child(odd)
{
background-color: powderblue;
}
tr:nth-child(1)
{
background-color: gray;
}
</style>
</head>
<body>
<section class="section-1">
<?php
require_once("classes/DataAccess.class.php");
$dao = new DataAccess();
if(isset($_POST["id"]))
{
$id=$_POST["id"];
if(isset($_POST["block"]))
{
$data["mgr_status"]="b";
}
elseif (isset($_POST["unblock"]))
{
$data["mgr_status"]="a";
}
else
{
//
}
if($dao->update($data,"tbl_manager","mgr_id=$id"))
{
$msg="success!";
}
}
//$fields=array("o_name","o_email","o_phone","o_address","o_licno","o_village","o_status");
if($managers = $dao->getData("*","tbl_manager"))
{
//var_dump(students);
?>
<table>
<tr>
<th>LICNO</th>
<th>NAME</th>
<th>EMAIL</th>
<th>ADDRESS</th>
<th>PHONE</th>
<th>DATE OF JOINING</th>
<th>STATUS</th>




</tr>
<?php
foreach($managers as $mgr)
{
?>
<form method="POST">
<tr>
<input type="hidden" name="id" value="<?php echo $mgr["mgr_id"];?>">
<td><?php echo $mgr["mgr_licno"]; ?></td>
<td><?php echo $mgr["mgr_name"]; ?></td>
<td><?php echo $mgr["mgr_email"]; ?></td>
<td><?php echo $mgr["mgr_address"]; ?></td>
<td><?php echo $mgr["mgr_phone"]; ?></td>
<td><?php echo $mgr["mgr_doj"]; ?></td>
<td><?php echo $mgr["mgr_status"]; ?></td>
                                

</tr>
</form>

<?php
}

?>

</table>


<?php
}
else
{
echo "<h3>No managers found ".$dao->getErrors()."</h3>";
}


?>

<button class="btn btn-success" id="print">PRINT</button>
<script>
document.getElementById("print").onclick=function()
{
window.print();
};
</script>
</section>
</div>

</body>
</html>

